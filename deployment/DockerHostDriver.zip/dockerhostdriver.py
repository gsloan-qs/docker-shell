﻿import requests
import json

from cloudshell.core.logger.qs_logger import get_qs_logger
from  cloudshell.shell.core.driver_context import *
from cloudshell.shell.core.resource_driver_interface import ResourceDriverInterface
from cloudshell.api.cloudshell_api import CloudShellAPISession, ResourceAttributesUpdateRequest, AttributeNameValue
import pprint

class DockerHostDriver (ResourceDriverInterface):
    def __init__(self):
        pass

    # Initialize the driver session, this function is called everytime a new instance of the driver is created
    # This is a good place to load and cache the driver configuration, initiate sessions etc.
    def initialize(self, context):
        """
        :type context: cloudshell.shell.core.driver_context.InitCommandContext
        """
        return 'Finished initializing'

    # Destroy the driver session, this function is called everytime a driver instance is destroyed
    # This i    s a good place to close any open sessions, finish writing to log files
    def cleanup(self):
        pass

    def getContainers(self, context):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceCommandContext
        """
        address = context.resource.address
        response = requests.get('{address}:4000/containers/json'.format(address=address) )
        return response.json()

    def destroy(self, context, ports):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceRemoteCommandContext
        """
        vm_info_json =context.remote_endpoints[0].app_context.deployed_app_json
        vm_info_obj = json.loads(vm_info_json)
        uid = vm_info_obj['vmdetails']['uid']
        log = ""
        address = context.resource.address
        response = requests.post('{address}:4000/containers/{uid}/stop'.format(address=address, uid=uid) )
        log+=str(response.status_code) + ": " + response.content
        response = requests.delete('{address}:4000/containers/{uid}'.format(address=address, uid=uid) )
        log = log + '\n' + str(response.status_code) + ": " + response.content
        session = CloudShellAPISession(host=context.connectivity.server_address,token_id=context.connectivity.admin_auth_token,domain='Global')
        session.DeleteResource(context.remote_endpoints[0].name)
        return log


    def _wrapInParenthesis(self, value):
        value = value.strip()
        if not value.startswith('"'):
            value = '"' + value
        if not value.endswith('"'):
            value += '"'
        return value

    def _jsonizeEnvNameValue(self, variable):
        #name_val = variable.split('=')
        #variable = self._wrapInParenthesis(name_val[0]) + "=" + self._wrapInParenthesis(name_val[1])
        return self._wrapInParenthesis(variable)


    def print_app_context(self,context):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceCommandContext
        :type image: str

        """
        return context.resource.app_context.app_request_json

    def _get__deploy_request(self,env, port_config, image):
        request_segments = []
        host_config_segments = []
        request_segments.append('"Cmd":[]')
        if len(env.strip()) > 0:
            env_variables = env
            env_variables_arr = env_variables.split(",")
            env_variables= ', '.join([self._jsonizeEnvNameValue(x) for x in env_variables_arr])
            request_segments.append('"Env" : [{env_variables}]'.format(env_variables=env_variables))
        else:
            request_segments.append('"Env" : []')

        if len(port_config.strip()):
            ports = port_config.split(",")
            exposed_ports =  '"ExposedPorts": {{ {exposed_ports} }}'\
                .format(exposed_ports= ', '.join(['"{port}/tcp": {{}}'.format(port=port) for port in ports ]))
            request_segments.append(exposed_ports)
            port_binding =   '"PortBindings": {{ {port_binding} }}'\
                .format(port_binding=", ".join( '"{port}/tcp": [{{ "HostPort": "" }}]'.format(port=port) for port in ports))
            host_config_segments.append(port_binding)

        request_segments.append('"Image":"{image}"'.format(image=image))
        host_config_segments.append('"PublishAllPorts": true')

        host_config_section = '"HostConfig": {{ {host_config} }}'.format(host_config=", ".join(host_config_segments) )
        request_segments.append(host_config_section)
        request_section = ', '.join(request_segments)
        return '{{ {request_section} }}'.format(request_section=request_section)

    def deployImage(self, context, image, env, port_config, app):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceCommandContext
        :type image: str

        """

        create_request_data = self._get__deploy_request(env,port_config,image)

      #  create_request_data = '{{ "Image":"{image}", "Env" : [{env_variables}],  "ExposedPorts": {{ "80/tcp": {{}} }}, "HostConfig": {{  "PublishAllPorts": true, "PortBindings": {{ "80/tcp": [{{ "HostPort": "" }}] }} }} }}  '.\
       #     format(image=image, env_variables=env_variables)

       # create_request_data = '{{ "Image":"{image}", "Env" : [{env_variables}],  {exposed_ports} "HostConfig": {{  "PublishAllPorts": true {port_binding} }} }}  '.\
        #    format(image=image, exposed_ports=exposed_ports, env_variables=env_variables,port_binding=port_binding)

        self._get_api_session(context).WriteMessageToReservationOutput(context.reservation.reservation_id,"sending: " + create_request_data)

        address = context.resource.address
        response = None
        try:
            response = requests.post('{address}:4000/containers/create'.format(address=address),
                                     create_request_data)

        except Exception as e:
            self._get_api_session(context).WriteMessageToReservationOutput(context.reservation.reservation_id,"error" + e.message)


        self._get_api_session(context).WriteMessageToReservationOutput(context.reservation.reservation_id,"response" + response.content)

        container_id = response.json()["Id"]

        str = '{ "vm_name" : "%s", "vm_uuid" : "%s", "cloud_provider_resource_name" : "%s"}' % (image.replace('/','_').replace(':','_') ,container_id, context.resource.name)

        return json.loads(str)

    # the name is by the Qualisystems conventions
    def remote_refresh_ip(self, context, ports):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceRemoteCommandContext
        """
        json = self.inspect(context,ports)
        ip = json["Node"]["IP"]
        ports = json["NetworkSettings"]["Ports"]
        if ('22/tcp' in ports):
            attchanges = [ResourceAttributesUpdateRequest(context.remote_endpoints[0].name,[AttributeNameValue(Name="SSH_Port", Value=ports['22/tcp'][0]['HostPort'])])]
            self._get_api_session(context).SetAttributesValues(  resourcesAttributesUpdateRequests=attchanges)
        if ('80/tcp' in ports):
            attchanges = [ResourceAttributesUpdateRequest(context.remote_endpoints[0].name,[AttributeNameValue(Name="WWW_Port", Value=ports['80/tcp'][0]['HostPort'])])]
            self._get_api_session(context).SetAttributesValues(  resourcesAttributesUpdateRequests=attchanges)
        if ('8000/tcp' in ports):
            attchanges = [ResourceAttributesUpdateRequest(context.remote_endpoints[0].name,[AttributeNameValue(Name="WWW_Port", Value=ports['8000/tcp'][0]['HostPort'])])]
            self._get_api_session(context).SetAttributesValues(  resourcesAttributesUpdateRequests=attchanges)

        self._get_api_session(context).UpdateResourceAddress(resourceFullPath=context.remote_endpoints[0].name,resourceAddress='52.38.2.8')


    def _get_api_session(self, context):
        """
        :type context: cloudshell.shell.core.driver_context.ResourceCommandContext
        """
        return CloudShellAPISession(domain="Global", host=context.connectivity.server_address, token_id=context.connectivity.admin_auth_token, port=context.connectivity.cloudshell_api_port)



    def inspect(self, context, ports ):
        address = context.resource.address
        vm_info_json =context.remote_endpoints[0].app_context.deployed_app_json
        vm_info_obj = json.loads(vm_info_json)
        uid = vm_info_obj['vmdetails']['uid']
        response = requests.get('{address}:4000/containers/{uid}/json'.format(address=address, uid=uid) )
        result = response.json()
        return result


    # the name is by the Qualisystems conventions
    def show_logs(self, context, ports):
        address = context.resource.address
        vm_info_json =context.remote_endpoints[0].app_context.deployed_app_json
        vm_info_obj = json.loads(vm_info_json)
        uid = vm_info_obj['vmdetails']['uid']
        response = requests.get('{address}:4000/containers/{uid}/logs?stdout=1'.format(address=address, uid=uid) )
        return response.content

    def PowerOn(self, context, ports):
        """
        Powers on the remote vm
        :param cloudshell.shell.core.driver_context.ResourceRemoteCommandContext context: the context the command runs on
        :param list[string] ports: the ports of the connection between the remote resource and the local resource, NOT IN USE!!!
        """
        vm_info_json =context.remote_endpoints[0].app_context.deployed_app_json
        vm_info_obj = json.loads(vm_info_json)
        uid = vm_info_obj['vmdetails']['uid']
        log = ""
        address = context.resource.address

        response = requests.post('{address}:4000/containers/{uid}/start'.format(address=address, uid=uid) )
        log+=str(response.status_code) + ": " + response.content
        return log

    def power_on(self, context, vm_uuid, resource_fullname):
        uid = vm_uuid
        log = ""
        address = context.resource.address

        response = requests.post('{address}:4000/containers/{uid}/start'.format(address=address, uid=uid) )
        log+=str(response.status_code) + ": " + response.content
        return log

    # the name is by the Qualisystems conventions
    def PowerCycle(self, context, ports, delay):
        pass

    def PowerOff(self, context, ports):
        """
        Powers off the remote vm
        :param cloudshell.shell.core.driver_context.ResourceRemoteCommandContext context: the context the command runs on
        :param list[string] ports: the ports of the connection between the remote resource and the local resource, NOT IN USE!!!
        """
        vm_info_json =context.remote_endpoints[0].app_context.deployed_app_json
        vm_info_obj = json.loads(vm_info_json)
        uid = vm_info_obj['vmdetails']['uid']
        log = ""
        address = context.resource.address

        response = requests.post('http://{address}:4000/containers/{uid}/stop'.format(address=address, uid=uid)  )
        log+=str(response.status_code) + ": " + response.content
        return log
